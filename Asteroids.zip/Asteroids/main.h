#include "sre/SDLRenderer.hpp"
#include "sre/SpriteAtlas.hpp"
#include "SpaceShit.h"
#include "GameObject.h"
void ProcessEvents(SDL_Event &event);
void Update(float deltaTime);
void Render();