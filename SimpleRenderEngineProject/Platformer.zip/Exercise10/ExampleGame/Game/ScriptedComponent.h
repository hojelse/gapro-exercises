#pragma once

#include "Engine/Component.h"

class Component : public MyEngine::Component {
	// TODO (challenge) implement one of the architecture for scripting described in class
	// NB: may require changing the Engine, depending which one you want to implement
};